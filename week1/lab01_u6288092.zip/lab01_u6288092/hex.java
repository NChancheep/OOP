
public class hex 
{
	public static void printFirst()
	{
		System.out.println("  ______  ");
		System.out.println(" /      \\ ");
		System.out.println("/        \\ ");
	}
	public static void printSec()
	{
		System.out.println("\\        /");
		System.out.println(" \\______/");
	}
	public static void printThird()
	{
		System.out.println("+--------+\n");
	}
	public static void printForth()
	{
		System.out.println("|  STOP  |");
		
	}
}
