
public class EggStop 
{
	public static void main(String[] args)
	{
		hex hex1 = new hex();
		hex1.printFirst();
		hex1.printSec();
		System.out.println("");
		hex1.printFirst();
		hex1.printSec();
		hex1.printThird();
		hex1.printFirst();
		hex1.printForth();
		hex1.printSec();
		hex1.printThird();
	}
}
